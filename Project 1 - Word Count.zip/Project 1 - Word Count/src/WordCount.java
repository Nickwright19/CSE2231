import components.map.Map;
import components.map.Map1L;
import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 *
 *
 * @author Nick Wright
 *
 */

public final class WordCount {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private WordCount() {
    }

    /**
     * Sorts through input and puts all input into a map and a sequence.
     *
     * @param out
     *            output stream for log messages
     * @param input
     *            input stream to read terms and definitions
     * @param words
     *            map to store terms and definitions
     * @param sortedWords
     *            sequence to store sorted terms
     */
    private static void sortingInput(SimpleWriter out, SimpleReader input,
            Map<String, Integer> words, Sequence<String> sortedWords) {

        int currVal = 0;
        int amount = 0;
        String line = "";

        while (!input.atEOS()) {
            line = input.nextLine();
            int numb = 0; // Reset numb for each new line

            while (numb < line.length()) {
                String word = "";
                char charAt = line.charAt(numb);

                // While the character isn't a space, comma, period, or line break
                while (numb < line.length() && (charAt != ' ' && charAt != ','
                        && charAt != '.' && charAt != '\n' && charAt != '-'
                        && charAt != ';' && charAt != ':')) {
                    word += charAt;
                    numb++;

                    if (numb < line.length()) {
                        charAt = line.charAt(numb);
                    }
                }

                if (!word.isEmpty()) {
                    if (!words.hasKey(word)) {
                        words.add(word, 1);
                        sortedWords.add(amount, word);
                    } else {
                        currVal = words.value(word) + 1;
                        words.replaceValue(word, currVal);
                    }
                }

                numb++; // Move to the next character in the line
            }
        }

    }

    /**
     * Sorts the sequence in alphabetical order.
     *
     * @param words
     *            the sequence of words to be sorted
     * @param out
     *            output stream for log messages
     */
    public static void sortAlphabetically(Sequence<String> words,
            SimpleWriter out) {
        int n = words.length();
        boolean swapped;

        do {
            int pos1 = 0;
            int pos2 = 1;
            swapped = false;
            for (int i = 1; i < n; i++) {

                if (words.entry(pos1).compareToIgnoreCase(words.entry(pos2)) > 0) {
                    // Swap elements if they're in the wrong order
                    String at1 = "";
                    String at2 = "";
                    at1 = words.entry(pos1);
                    at2 = words.entry(pos2);
                    words.replaceEntry(pos2, at1);
                    words.replaceEntry(pos1, at2);

                    swapped = true;
                }
                pos1++;
                pos2++;
            }
            n--;
        } while (swapped);
    }

    /**
     * Prints the index HTML file.
     *
     * @param filePath
     *            path for the output file
     * @param sortedWords
     *            sequence of sorted words
     * @param words
     *            sequence of sorted words
     * @param out
     *            output stream to write HTML content
     */
    private static void printHTMLFile(String filePath,
            Map<String, Integer> words, Sequence<String> sortedWords,
            SimpleWriter out) {

        int leng = sortedWords.length();

        out.println("<HTML>");
        out.println("<Head>");
        out.println("\t <title>Word and Count</title>");
        out.println("</Head>");
        out.println("<style>");
        out.println("table, th, td {");
        out.println("\t border:1px solid black;");
        out.println("}");
        out.println("</style>");
        out.println("<body>");

        out.println();

        out.println("<h2>Words and Count</h2>");
        out.println("<hr>");

        out.println("<table style=\"width:100%\">");
        out.println("\t <tr>");
        out.println("\t \t <th>Word</th>");
        out.println("\t \t <th>Count</th>");
        out.println("\t </tr>");

        for (int x = 0; x < leng; x++) {
            //prints each set of words and the count with it
            out.println("\t <tr>");
            out.println("\t \t <td>" + sortedWords.entry(x) + "</td>");
            out.println(
                    "\t \t <td>" + words.value(sortedWords.entry(x)) + "</td>");
            out.println("\t </tr>");
        }

        out.println("</table>");
        out.println("</body>");
        out.println("</HTML>");

    }

    /**
     * Main method to manage glossary operations.
     *
     * @param args
     *            command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        //create the map used to store the terms and definitions
        Map<String, Integer> words = new Map1L<>();
        words.newInstance();

        //create the sequence used to store the terms
        Sequence<String> sortedWords = new Sequence1L<>();
        sortedWords.newInstance();

        //get input file path, store input in a string and initialize it in SR
        out.println("ex./Users/nickwright/Downloads/gettysburg.txt");
        out.println("Input file: ");
        String getFile = in.nextLine();
        SimpleReader input = new SimpleReader1L(getFile);

        //get the file path for the output folder
        out.println("ex. /Users/nickwright/Documents/School/gettysburg.html");
        out.println("Filepath for output files?: ");
        String outputFilePath = in.nextLine();

        //sort the input into the map and sequence
        sortingInput(out, input, words, sortedWords);

        //sort sequence to ensure alphabetical order
        sortAlphabetically(sortedWords, out);

        //ensure printHTMLFile is printed into a new file rather than console
        SimpleWriter fileout = new SimpleWriter1L(outputFilePath);
        printHTMLFile(outputFilePath, words, sortedWords, fileout);
        // Close input and output streams
        in.close();
        out.close();
    }

}
